# TODO List App


## Table of contents
* [General info](#general-info)
* [Technologies](#technologies)
* [Setup](#setup)

## General info
Build a Todo List App - you can add, edit and remove your daily tasks.
	
## Technologies
Project is created with:
* [HTML](#html)
* [CSS](#CSS)
* [Javascript](#Javascript)
	
## Setup
To run this project open file index.html.
